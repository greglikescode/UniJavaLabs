package openworld.terrain;

import openworld.Coordinates;
import openworld.Damage;
import openworld.World;

public class Grasslands extends Terrain{

    public Grasslands(String name, Coordinates location, int maxHealth, World world, Damage attack) {
        super(name, location, maxHealth, world, attack);
    
    }

    
    
}
