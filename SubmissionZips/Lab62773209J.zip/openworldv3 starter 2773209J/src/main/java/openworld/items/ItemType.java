package openworld.items;

public enum ItemType {
    WEAPON,
    ARMOUR,
}
