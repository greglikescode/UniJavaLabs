package openworld;

public enum DamageType {
    FIRE,
    ICE,
    ELECTRIC,
    PHYSICAL,
}
